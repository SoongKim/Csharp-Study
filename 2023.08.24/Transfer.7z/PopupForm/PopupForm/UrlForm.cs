namespace PopupForm
{
    public partial class UrlForm : Form
    {
        public UrlForm()
        {
            InitializeComponent();
        }

        internal string targetUrl;
        internal string targetPort;

        private void textBox1_TextChanged(object sender, EventArgs e){}

        private void textBox2_TextChanged(object sender, EventArgs e){}

        private void SetClick(object sender, EventArgs e)
        {
            targetUrl = UrlBox.Text;
            targetPort = PortBox.Text;
            string targetAccess = targetUrl + ":" + targetPort;
            MessageBox.Show("Url : " + targetAccess);
        }

    }
}