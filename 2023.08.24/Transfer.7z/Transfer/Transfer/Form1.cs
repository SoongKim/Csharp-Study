namespace Transfer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        internal string SelectedFilePath;

        private void FileBtnClick(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Title = "���� ����";
                ofd.Filter = "��� ����(*.*)|*.*";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    SelectedFilePath = ofd.FileName;
                    FileNameBox.Text = ofd.FileName;
                }
                else
                {
                    FileNameBox.Text = null;
                }
            }
        }

        private async void TransferClick(object sender, EventArgs e)
        {
            using(var urlForm = new UrlForm())
            {
                
            }
        }

        private async void UrlBtnClick(object sender, EventArgs e)
        {
            using(var urlForm = new UrlForm())
            {
                urlForm.ShowDialog();
                urlForm.Close();
            }
        }
    }
}