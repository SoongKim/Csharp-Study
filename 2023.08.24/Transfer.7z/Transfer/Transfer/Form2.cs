﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Transfer
{
    public partial class UrlForm : Form
    {
        internal string targetUrl;
        internal string targetPort;
        
        public UrlForm()
        {
            InitializeComponent();
        }

        private void SetClick(object sender, EventArgs e)
        {
            targetUrl = UrlBox.Text;
            targetPort = UrlBox.Text;
            string targetAccess = targetUrl + ":" + targetPort;
            MessageBox.Show("URL : " + targetAccess);
            this.Close();
        }
    }
}
